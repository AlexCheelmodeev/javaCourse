package HM08.DZ03;

public class App {
    public static void main(String[] args) {
        Person person = new Person();
        Person person1 = new Person("Vlad",20);
    }
}
