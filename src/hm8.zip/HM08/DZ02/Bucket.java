package HM08.DZ02;

public class Bucket {
}
