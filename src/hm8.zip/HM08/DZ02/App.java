package HM08.DZ02;

public class App {
    public static void main(String[] args) {
        Goods apple = new Goods("apple", 2, 5.4);
        Goods orange = new Goods("orange", 5, 5.7);
        Goods lemon = new Goods("lemon", 10, 2.8);

        Goods onion = new Goods("onion", 15, 5.2);
        Goods potato = new Goods("potato", 12, 5.2);
        Goods salad = new Goods("salad", 18, 5.5);

        Goods chicken = new Goods("chicken", 100, 8.8);
        Goods lamp = new Goods("lamp", 244, 10);
        Goods beef = new Goods("beef", 150, 9.9);

        









    }
}
