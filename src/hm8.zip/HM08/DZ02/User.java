package HM08.DZ02;

public class User {
    private String password;
    private String login;
}
