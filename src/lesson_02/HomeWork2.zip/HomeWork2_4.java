package lesson_02;
//Задача 4. Закомментируй часть кода, чтобы на экран вывелось сообщение "sum = 12"
public class HomeWork2_4 {
    public static void main(String[] args) {
        int a = 3;
        //int a = 10;
        int b = 6;
        //int b = 12;
       // int sum = 1 + a + b;
       // int sum = 2 + a + b;
        int sum = 3 + a + b;
       // int sum = 4 + a + b;

        System.out.println("sum = " + sum);
    }
}
