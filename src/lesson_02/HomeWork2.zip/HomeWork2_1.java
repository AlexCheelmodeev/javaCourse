package lesson_02;

public class HomeWork2_1 {
    public static void main(String[] args) {
        //Задача 1. Дано: Хитрый бухгалтер разделил 5 рублей на 2 кассы. Сколько рублей лежит в каждой кассе?
        //Вывести на консоль
        double money = 5;
        double result = money / 2;

        System.out.println("В кассе лежит " + result + " рубля");

















        }
}
