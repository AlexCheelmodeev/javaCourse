package lesson_02;

public class HomeWork2_2 {
    public static void main(String[] args) {
        //Задача 2. Дано: Стороны квадрата a = 50, b = 20. Найти площадь.
        //Вывести на консоль
        int a = 50;
        int b = 20;
        int x = a * b;
        System.out.println("Площадь квадрата составляет " + x);
    }
}
