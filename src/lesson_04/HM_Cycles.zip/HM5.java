package lesson_04.mwCIkles;

public class HM5 {
    public static void main(String[] args) {

        int a = 1;
        while (a <= 10) {
            System.out.print(a + " ");
            System.out.print(a * 2 + " ");
            System.out.print(a * 3 + " ");
            System.out.print(a * 4 + " ");
            System.out.print(a * 7 + " ");
            System.out.print(a * 6 + " ");
            System.out.print(a * 7 + " ");
            System.out.print(a * 8 + " ");
            System.out.print(a * 9 + " ");
            System.out.print(a * 10 + " ");
            System.out.println();
            a++;
        }
    }


}

